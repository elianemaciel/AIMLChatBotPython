from django.shortcuts import render

def my_view(request):
    pass

